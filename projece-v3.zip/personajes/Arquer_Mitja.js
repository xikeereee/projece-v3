const { Base } = require("./Base.js");

class Arquer_Mitja extends Base {

    constructor() { // Constructor para Mostrar valores a escoger
        super();
        this.Nom = "Arquer Mitja";
        this.Vida = 50;
        this.Poder = 30;
        this.Velocitat = 20;
    }


    tirPrecis(enemic) {
        enemic.modVida(-this.Poder);
    }


    tirMultiple(enemic) {
        const cops = Math.floor(Math.random() * 3) + 1;
        const dany = this.Poder * 0.5;




        for (let i = 0; i < cops; i++) {
            enemic.modVida(-dany)
        }
    }
}

module.exports = Arquer_Mitja;